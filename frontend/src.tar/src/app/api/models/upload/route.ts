import { NextRequest, NextResponse } from "next/server";
import { getSessionToken } from "@/lib/api/session";

/**
 * Proxies a multipart model-file upload directly to the backend /models/upload endpoint.
 * The previous implementation called the wrong route (/models/ with query params),
 * which caused 422 errors and never actually sent the file to the backend.
 */
export async function POST(req: NextRequest) {
  const token = await getSessionToken();
  if (!token) {
    return NextResponse.json({ message: "Not authenticated" }, { status: 401 });
  }

  let formData: FormData;
  try {
    formData = await req.formData();
  } catch {
    return NextResponse.json({ message: "Invalid upload form." }, { status: 400 });
  }

  const displayName = formData.get("display_name");
  const baseModelKey = formData.get("base_model_key");
  const file = formData.get("file");

  if (!displayName || typeof displayName !== "string") {
    return NextResponse.json({ message: "display_name is required." }, { status: 400 });
  }
  if (!(file instanceof File)) {
    return NextResponse.json({ message: "file is required." }, { status: 400 });
  }

  const API_URL =
    process.env.NEXT_PUBLIC_API_URL ??
    process.env.API_URL ??
    "http://localhost:8000";

  try {
    // Forward the file + metadata to the backend's dedicated upload endpoint
    const backendForm = new FormData();
    backendForm.append("file", file, file.name);
    backendForm.append("display_name", displayName);
    backendForm.append("base_model_key", String(baseModelKey ?? "custom"));

    const res = await fetch(`${API_URL}/models/upload`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        // Do NOT set Content-Type here — let fetch set it with the correct boundary
      },
      body: backendForm,
      // @ts-expect-error — Node 18 fetch accepts duplex for streaming
      duplex: "half",
    });

    const data = await res.json().catch(() => ({}));

    if (!res.ok) {
      return NextResponse.json(
        { message: data?.detail ?? data?.message ?? "Upload failed" },
        { status: res.status }
      );
    }

    return NextResponse.json(data, { status: 201 });
  } catch (err) {
    console.error("[upload-model] proxy error:", err);
    return NextResponse.json({ message: "Failed to upload model" }, { status: 500 });
  }
}